INSERT INTO warehouse_product_categories( name, description) VALUES ('CAT1', 'Categoria 1');
INSERT INTO warehouse_product_categories( name, description) VALUES ('CAT2', 'Categoria 2');
INSERT INTO warehouse_product_categories( name, description) VALUES ('CAT3', 'Otro texto');